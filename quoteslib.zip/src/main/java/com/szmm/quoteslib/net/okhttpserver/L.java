package com.szmm.quoteslib.net.okhttpserver;

import android.util.Log;

import com.szmm.quoteslib.comment.GlobalVariable;

/** 日志工具类 */
public class L {
    public static boolean debug = GlobalVariable.DEBUG;
    public static String tag = GlobalVariable.OKHTTP_SERVER_TAG;

    public static void v(String msg) {
        if (debug) Log.v(tag, msg);
    }

    public static void d(String msg) {
        if (debug) Log.d(tag, msg);
    }

    public static void i(String msg) {
        if (debug) Log.i(tag, msg);
    }

    public static void w(String msg) {
        if (debug) Log.w(tag, msg);
    }

    public static void e(String msg) {
        if (debug) Log.e(tag, msg);
    }
}

