package com.szmm.quoteslib.utils;

import android.app.Activity;
import android.util.DisplayMetrics;

/**
 * Created by Tim on 2016/7/25.
 * 获取屏幕尺寸
 */
public class ScreenUtil {
    //获取屏幕宽度
    public static int getScreenWidth(Activity activity){
        DisplayMetrics dm = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
        return dm.widthPixels;
    }
    //获取屏幕高度
    public static int getScreenHeight(Activity activity){
        DisplayMetrics dm = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
        return dm.heightPixels;
    }
}
