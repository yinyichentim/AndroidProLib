package com.szmm.quoteslib.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Create by Tim on 2016/7/27
 * 正则表单验证工具类
 * **/
public class FormValidateUtils {
    private static final String V_MTALK_NO_CHANGE_NUM="^[0-9]+$";       //纯数字
    private static final String V_MTALK_NUM="^(?=.*[a-zA-Z])[A-Za-z0-9_]*$";          //MTalk号
    private static final String V_INTEGER="^-?[1-9]\\d*$";          //整数
    private static final String V_Z_INDEX="^[1-9]\\d*$";            //
    private static final String V_NEGATIVE_INTEGER="^-[1-9]\\d*$";
    private static final String V_NUMBER="^([+-]?)\\d*\\.?\\d+$";
    private static final String V_POSITIVE_NUMBER="^[1-9]\\d*|0$";
    private static final String V_NEGATINE_NUMBER="^-[1-9]\\d*|0$";
    private static final String V_FLOAT="^([+-]?)\\d*\\.\\d+$";
    private static final String V_POSTTIVE_FLOAT="^[1-9]\\d*.\\d*|0.\\d*[1-9]\\d*$";
    private static final String V_NEGATIVE_FLOAT="^-([1-9]\\d*.\\d*|0.\\d*[1-9]\\d*)$";
    private static final String V_UNPOSITIVE_FLOAT="^[1-9]\\d*.\\d*|0.\\d*[1-9]\\d*|0?.0+|0$";
    private static final String V_UN_NEGATIVE_FLOAT="^(-([1-9]\\d*.\\d*|0.\\d*[1-9]\\d*))|0?.0+|0$";
    private static final String V_EMAIL="^\\w+((-\\w+)|(\\.\\w+))*\\@[A-Za-z0-9]+((\\.|-)[A-Za-z0-9]+)*\\.[A-Za-z0-9]+$";
    private static final String V_COLOR="^[a-fA-F0-9]{6}$";
    private static final String V_URL="((http|ftp|https)://)(([a-zA-Z0-9\\._-]+\\.[a-zA-Z]{2,6})|([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}))(:[0-9]{1,4})*(/[a-zA-Z0-9\\&%_\\./-~-]*)?";
    private static final String V_CHINESE="^[\\u4E00-\\u9FA5\\uF900-\\uFA2D]+$";
    private static final String V_ASCII="^[\\x00-\\xFF]+$";
    private static final String V_ZIPCODE="^\\d{6}$";
    private static final String V_MOBILE="^1[0123456789]\\d{9}$";          //手机号码
    private static final String V_IP4="^(25[0-5]|2[0-4]\\d|[0-1]\\d{2}|[1-9]?\\d)\\.(25[0-5]|2[0-4]\\d|[0-1]\\d{2}|[1-9]?\\d)\\.(25[0-5]|2[0-4]\\d|[0-1]\\d{2}|[1-9]?\\d)\\.(25[0-5]|2[0-4]\\d|[0-1]\\d{2}|[1-9]?\\d)$";
    private static final String V_NOTEMPTY="^\\S+$";
    private static final String V_PICTURE="(.*)\\.(jpg|bmp|gif|ico|pcx|jpeg|tif|png|raw|tga)$";
    private static final String V_RAR="(.*)\\.(rar|zip|7zip|tgz)$";
    private static final String V_DATE="^((((1[6-9]|[2-9]\\d)\\d{2})-(0?[13578]|1[02])-(0?[1-9]|[12]\\d|3[01]))|(((1[6-9]|[2-9]\\d)\\d{2})-(0?[13456789]|1[012])-(0?[1-9]|[12]\\d|30))|(((1[6-9]|[2-9]\\d)\\d{2})-0?2-(0?[1-9]|1\\d|2[0-8]))|(((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))-0?2-29-)) (20|21|22|23|[0-1]?\\d):[0-5]?\\d:[0-5]?\\d$";
    private static final String V_QQ_NUMBER="^[1-9]*[1-9][0-9]*$";
    private static final String V_TEL="^(([0\\+]\\d{2,3}-)?(0\\d{2,3})-)?(\\d{7,8})(-(\\d{3,}))?$";
    private static final String V_USERNAME="^\\w+$";
    private static final String V_LETTER="^[A-Za-z]+$";
    private static final String V_LETTER_U="^[A-Z]+$";
    private static final String V_LETTER_I="^[a-z]+$";
    private static final String V_IDCARD ="^(\\d{15}$|^\\d{18}$|^\\d{17}(\\d|X|x))$";
    private static final String V_PASSWORD_REG="[A-Za-z]+[0-9]";
    private static final String V_PASSWORD_LENGTH="^\\d{6,18}$";
    private static final String V_31DAYS="^((0?[1-9])|((1|2)[0-9])|30|31)$";
    private FormValidateUtils() {

    }

    public static boolean MTalkNumBer(String value){
        return match(V_MTALK_NUM,value);
    }
    public static boolean noMTalkNumBerChange(String value){
        return match(V_MTALK_NO_CHANGE_NUM,value);
    }

    public static boolean Integer(String value){
        return match(V_INTEGER,value);
    }
 
    public static boolean Z_index(String value){
        return match(V_Z_INDEX,value);
    }
 
    public static boolean Negative_integer(String value){
        return match(V_NEGATIVE_INTEGER,value);
    }
  
    public static boolean Number(String value){
        return match(V_NUMBER,value);
    }
 
    public static boolean PositiveNumber(String value){
        return match(V_POSITIVE_NUMBER,value);
    }
 
    public static boolean NegatineNumber(String value){
        return match(V_NEGATINE_NUMBER,value);
    }
 
    public static boolean Is31Days(String value){
        return match(V_31DAYS,value);
    }
 
    public static boolean ASCII(String value){
        return match(V_ASCII,value);
    }
 
    public static boolean Chinese(String value){
        return match(V_CHINESE,value);
    }
 
    public static boolean Color(String value){
        return match(V_COLOR,value);
    }
 
    public static boolean Date(String value){
        return match(V_DATE,value);
    }
 
    public static boolean Email(String value){
        return match(V_EMAIL,value);
    }
 
    public static boolean Float(String value){
        return match(V_FLOAT,value);
    }
 
    public static boolean IDcard(String value){
        return match(V_IDCARD,value);
    }
 
    public static boolean IP4(String value){
        return match(V_IP4,value);
    }
 
    public static boolean Letter(String value){
        return match(V_LETTER,value);
    }
 
    public static boolean Letter_i(String value){
        return match(V_LETTER_I,value);
    }
 
    public static boolean Letter_u(String value){
        return match(V_LETTER_U,value);
    }
 
    public static boolean Mobile(String value){
        return match(V_MOBILE,value);
    }
 
    public static boolean Negative_float(String value){
        return match(V_NEGATIVE_FLOAT,value);
    }
 
    public static boolean Notempty(String value){
        return match(V_NOTEMPTY,value);
    }
 
    public static boolean Number_length(String value){
        return match(V_PASSWORD_LENGTH,value);
    }
 
    public static boolean Password_reg(String value){
        return match(V_PASSWORD_REG,value);
    }
 
    public static boolean Picture(String value){
        return match(V_PICTURE,value);
    }
 
    public static boolean Posttive_float(String value){
        return match(V_POSTTIVE_FLOAT,value);
    }
 
    public static boolean QQnumber(String value){
        return match(V_QQ_NUMBER,value);
    }
 
    public static boolean Rar(String value){
        return match(V_RAR,value);
    }
 
    public static boolean Tel(String value){
        return match(V_TEL,value);
    }
 
    public static boolean Un_negative_float(String value){
        return match(V_UN_NEGATIVE_FLOAT,value);
    }

    public static boolean Unpositive_float(String value){
        return match(V_UNPOSITIVE_FLOAT,value);
    }
 
    public static boolean Url(String value){
        return match(V_URL,value);
    }
 
    public static boolean UserName(String value){
        return match(V_USERNAME,value);
    }
 
    public static boolean Zipcode(String value){
        return match(V_ZIPCODE,value);
    }
 
    /**模式匹配**/
    private static boolean match(String regex, String str)
    {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        return matcher.matches();
    }
}