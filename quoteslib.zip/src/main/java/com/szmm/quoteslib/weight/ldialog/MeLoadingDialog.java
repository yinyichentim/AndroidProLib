package com.szmm.quoteslib.weight.ldialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.szmm.quoteslib.R;
/**
 * 加载弹框
 * Created by Android-Tim on 2016/11/10.
 */

public class MeLoadingDialog extends Dialog {

    private TextView tv;

    public MeLoadingDialog(Context context) {
        super(context, R.style.loadingDialogStyle);
        this.setCanceledOnTouchOutside(false);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.me_loading_dialog);
        tv = (TextView)findViewById(R.id.tv);
        tv.setText("");
        LinearLayout linearLayout = (LinearLayout)this.findViewById(R.id.LinearLayout);
        linearLayout.getBackground().setAlpha(210);
    }

}
