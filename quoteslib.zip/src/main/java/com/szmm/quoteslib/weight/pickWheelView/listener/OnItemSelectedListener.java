package com.szmm.quoteslib.weight.pickWheelView.listener;


public interface OnItemSelectedListener {
    void onItemSelected(int index);
}
