package com.szmm.quoteslib.weight.imageselector;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;

import java.util.ArrayList;

/**
 * Created by zgh on 2016/8/23.
 */
public class ImageSelector {
    private static String path = "";
    @TargetApi(Build.VERSION_CODES.M)
    public static  void toSelector(Activity mActivity, int count,ArrayList<String>  list){
       /* if(ContextCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
            Log.i("angio",124+"");
            if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                ActivityCompat.requestPermissions(mActivity,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_READ_CONTACTS);
            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(mActivity,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_READ_CONTACTS);
            }

        }else {*/
        if (count!= Max_IMAGES_COUNT){
            Max_IMAGES_COUNT = count;
            clear();
        }
        if(list!=null) {
            imageList = list;
        }
        int RESIDUE_IMAGES_COUNT = Max_IMAGES_COUNT - imageList.size();
        Intent intent = new Intent(mActivity,ImageSelectorActivity.class);
        intent.putExtra(CHOOSE_IMAGE_COUNT,RESIDUE_IMAGES_COUNT);
        mActivity.startActivityForResult(intent,1001);
        //}
    }
    @TargetApi(Build.VERSION_CODES.M)
    public static  void toSelector(Activity mActivity, int count){
       /* if(ContextCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
            Log.i("angio",124+"");
            if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                ActivityCompat.requestPermissions(mActivity,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_READ_CONTACTS);
            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(mActivity,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_READ_CONTACTS);
            }

        }else {*/
        if (count!= Max_IMAGES_COUNT){
            Max_IMAGES_COUNT = count;
            clear();
        }
        int RESIDUE_IMAGES_COUNT = Max_IMAGES_COUNT - imageList.size();
        Intent intent = new Intent(mActivity,ImageSelectorActivity.class);
        intent.putExtra(CHOOSE_IMAGE_COUNT,RESIDUE_IMAGES_COUNT);
        mActivity.startActivityForResult(intent,1001);
        //}
    }
    @TargetApi(Build.VERSION_CODES.M)
    public static  void toSelector(Activity mActivity, int count,String tag){
        TAG = tag;
       /* if(ContextCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
            Log.i("angio",124+"");
            if (ActivityCompat.shouldShowRequestPermissionRationale(mActivity,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                ActivityCompat.requestPermissions(mActivity,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_READ_CONTACTS);
            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions(mActivity,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_READ_CONTACTS);
            }

        }else {*/
        if (count!= Max_IMAGES_COUNT){
            Max_IMAGES_COUNT = count;
            clear();
        }
        int RESIDUE_IMAGES_COUNT = Max_IMAGES_COUNT - imageList.size();
        Intent intent = new Intent(mActivity,ImageSelectorActivity.class);
        intent.putExtra(CHOOSE_IMAGE_COUNT,RESIDUE_IMAGES_COUNT);
        mActivity.startActivityForResult(intent,1001);
        //}
    }
    public static void toCamera(Activity mActivity,int count,ArrayList<String> list){
        if (count!= Max_IMAGES_COUNT){
            Max_IMAGES_COUNT = count;
            clear();
        }
        if(list!=null) {
            imageList = list;
        }
        Intent intent = new Intent(mActivity, ImageSelectorCameraActivity.class);
        mActivity.startActivityForResult(intent, TAKE_PICTURE);
    }
    public static void toCamera(Activity mActivity,int count){
        if (count!= Max_IMAGES_COUNT){
            Max_IMAGES_COUNT = count;
            clear();
        }
            Intent intent = new Intent(mActivity, ImageSelectorCameraActivity.class);
            mActivity.startActivityForResult(intent, TAKE_PICTURE);
       //}
    }
    public static void toCamera(Activity mActivity,int count,String tag){
        TAG = tag;
        if (count!= Max_IMAGES_COUNT){
            Max_IMAGES_COUNT = count;
            clear();
        }
        Intent intent = new Intent(mActivity, ImageSelectorCameraActivity.class);
        mActivity.startActivityForResult(intent, TAKE_PICTURE);
        //}
    }

    private final static int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 111;
    public final static String DIRS ="startActivityForDirs";
    public static int RESULTCODE = 864213579;
    public static int SURE = 135792468;
    public static int TAKE_PICTURE = 23134;
    static String CHOOSE_IMAGE_COUNT ="CHOOSE_IMAGE_COUNT";
    static String CHOOSE_IMAGE_IBUM  ="CHOOSE_IMAGE_IBUM";
    static int Max_IMAGES_COUNT = 0;
    //剩余的数目
    int RESIDUE_IMAGES_COUNT = 0;
    //记录用户选择数据的集合
    static ArrayList<String> imageList = new ArrayList<>();
    public static void clear(){
        imageList.clear();
    }
    public static String TAG =null;
}
