package com.szmm.quoteslib.weight.imageselector;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.szmm.quoteslib.R;

import java.io.Serializable;
import java.util.ArrayList;

public class ImageSelectorActivity extends AppCompatActivity implements View.OnClickListener{
    private TextView cancle;
    private ImageView imageView;
    private ListView mListView;
    private ArrayList<ImageaIbum> mDataList = new ArrayList<>();
    private ImageFetcher mHelper;
    private ImageSelectorAdapter adapter;
    private int chooseCount;
    private final int REQUECT_CODE_SDCARD=1234;
    private RelativeLayout layout ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all_images);
        initView();
        cancle.setOnClickListener(this);
        cancle.setOnClickListener(this);
        imageView.setOnClickListener(this);
        chooseCount=getIntent().getIntExtra(ImageSelector.CHOOSE_IMAGE_COUNT,0);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(ImageSelectorActivity.this,ImageSelectorChooseActivity.class);
                intent.putExtra(ImageSelector.CHOOSE_IMAGE_COUNT,chooseCount);
                intent.putExtra(ImageSelector.CHOOSE_IMAGE_IBUM,(Serializable) mDataList.get(position).imageList);
                startActivityForResult(intent,100);

            }
        });
        if (ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED)
        {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUECT_CODE_SDCARD);
            }else{
                ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUECT_CODE_SDCARD);

            }
        } else
        {
            initData();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
    {
        if (requestCode == REQUECT_CODE_SDCARD)
        {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                initData();
            } else
            {
                AlertDialog.Builder builder = new AlertDialog.Builder(ImageSelectorActivity.this);
                builder.setMessage(getResources().getString(R.string.imageselector_cannont_read));
                builder.setTitle(getString(R.string.hite_title));
                builder.setCancelable(false);
                builder.setPositiveButton(getString(R.string.finish_sure), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ImageSelectorActivity.this.finish();
                    }
                });
                builder.create().show();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }


   /* @PermissionGrant(REQUECT_CODE_SDCARD)
    public void requestSdcardSuccess()
    {
        initData();
        //Toast.makeText(this, "GRANT ACCESS SDCARD!", Toast.LENGTH_SHORT).show();
    }

    @PermissionDenied(REQUECT_CODE_SDCARD)
    public void requestSdcardFailed()
    {
        //Toast.makeText(this, "DENY ACCESS SDCARD!", Toast.LENGTH_SHORT).show();
        Toast.makeText(this,"未开启文件读取权限，无法选择图片",Toast.LENGTH_SHORT).show();
        finish();
    }*/
    private void initData(){
        layout.setVisibility(View.VISIBLE);
        mHelper = ImageFetcher.getInstance(getApplicationContext());
        mDataList = mHelper.getImagesBucketList(false);
        //将所有图片放到集合的第0个位置
        ImageaIbum  imageaIbum = new ImageaIbum();
        ArrayList<ImageItem> imageItems = new ArrayList<>();
        for(int i = 0;i < mDataList.size();i++){
            imageItems.addAll(mDataList.get(i).getImageList());
        }
        imageaIbum.setImageList(imageItems);
        imageaIbum.setBucketName(getResources().getString(R.string.imageselector_all_img));
        imageaIbum.setCount(imageItems.size());
        mDataList.add(0,imageaIbum);

        adapter = new ImageSelectorAdapter(ImageSelectorActivity.this,mDataList);
        mListView.setAdapter(adapter);
    }

    private void initView(){
        mListView = (ListView) findViewById(R.id.imageSelectorlv);
        cancle = (TextView) findViewById(R.id.imageSelector_cancle);
        imageView = (ImageView) findViewById(R.id.imageSelector_return);
        layout = (RelativeLayout) findViewById(R.id.imageSelector_layout);
        layout.setVisibility(View.INVISIBLE);

    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.imageSelector_cancle) {
            finish();

        } else if (i == R.id.imageSelector_return) {
            finish();

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==ImageSelector.SURE){
            setResult(ImageSelector.RESULTCODE,data);
            finish();
        }
    }
}
