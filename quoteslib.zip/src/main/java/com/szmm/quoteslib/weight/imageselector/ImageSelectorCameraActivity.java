package com.szmm.quoteslib.weight.imageselector;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;

import com.szmm.quoteslib.R;

import java.io.File;

public class ImageSelectorCameraActivity extends AppCompatActivity {
    private String path ="";
    private final int REQUECT_CODE_CAMERA = 2332;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_selector_camera);
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED)
        {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    REQUECT_CODE_CAMERA);
        } else
        {
           initData();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
    {
        if (requestCode == REQUECT_CODE_CAMERA)
        {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
               initData();
            } else
            {
                AlertDialog.Builder builder = new AlertDialog.Builder(ImageSelectorCameraActivity.this);
                builder.setMessage(getResources().getString(R.string.imageselector_cannotuser_camera));
                builder.setTitle(getString(R.string.hite_title));
                builder.setCancelable(false);
                builder.setPositiveButton(getString(R.string.finish_sure), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        finish();
                    }
                });
                builder.create().show();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void initData() {
        Intent openCameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File vFile = new File(Environment.getExternalStorageDirectory()
                + "/myimage/", String.valueOf(System.currentTimeMillis())
                + ".jpg");
        if (!vFile.exists()) {
            File vDirPath = vFile.getParentFile();
            vDirPath.mkdirs();
        } else {
            if (vFile.exists()) {
                vFile.delete();
            }
        }
        path = vFile.getPath();
        Uri cameraUri = Uri.fromFile(vFile);
        openCameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
        startActivityForResult(openCameraIntent, ImageSelector.TAKE_PICTURE);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Intent intent = new Intent();
        if (ImageSelector.imageList.size()<ImageSelector.Max_IMAGES_COUNT){
            File file = new File(path);
            if(file.exists()&&file.length()>0) {
                ImageSelector.imageList.add(path);
            }
        }
        intent.putStringArrayListExtra(ImageSelector.DIRS,ImageSelector.imageList);
        setResult(ImageSelector.RESULTCODE,intent);
        finish();
    }
}
