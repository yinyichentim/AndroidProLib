package com.szmm.quoteslib.weight.imageselector;

import android.content.Context;
import android.database.Cursor;
import android.provider.MediaStore;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by Administrator on 2016/8/24 0024.
 */
public class ImageFetcher {
    private static ImageFetcher instance;
    private Context mContext;
    private HashMap<String, ImageaIbum> mBucketList = new HashMap<String, ImageaIbum>();
    private HashMap<String, String> mThumbnailList = new HashMap<String, String>();

    private ImageFetcher()
    {
    }

    private ImageFetcher(Context context)
    {
        this.mContext = context;
    }

    public static ImageFetcher getInstance(Context context)
    {
        // if(context==null)
        // context = MyApplication.getMyApplicationContext(); TODO

        if (instance == null)
        {
            synchronized (ImageFetcher.class)
            {
                instance = new ImageFetcher(context);
            }
        }
        return instance;
    }

    /**
     * 是否已加载过了相册集合
     */
    boolean hasBuildImagesBucketList = false;

    /**
     * 得到图片集
     *
     * @param refresh
     * @return
     */
    public ArrayList<ImageaIbum> getImagesBucketList(boolean refresh)
    {
        if (refresh || (!refresh && !hasBuildImagesBucketList))
        {
            buildImagesBucketList();
        }
        ArrayList<ImageaIbum> tmpList = new ArrayList<ImageaIbum>();
        Iterator<Map.Entry<String, ImageaIbum>> itr = mBucketList.entrySet()
                .iterator();
        while (itr.hasNext())
        {
            Map.Entry<String, ImageaIbum> entry = itr
                    .next();
            tmpList.add(entry.getValue());
        }
        return tmpList;
    }

    /**
     * 得到图片集
     */
    private void buildImagesBucketList()
    {
        Cursor cur = null;
        try
        {
            long startTime = System.currentTimeMillis();

            // 构造缩略图索引
            getThumbnail();

            // 构造相册索引
            String columns[] = new String[] { MediaStore.Images.Media._ID, MediaStore.Images.Media.BUCKET_ID,
                    MediaStore.Images.Media.DATA, MediaStore.Images.Media.BUCKET_DISPLAY_NAME };
            // 得到一个游标
            cur = mContext.getContentResolver().query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, columns, null, null, null);
            if (cur.moveToFirst())
            {
                // 获取指定列的索引
                int photoIDIndex = cur.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                int photoPathIndex = cur.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                int bucketDisplayNameIndex = cur
                        .getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME);
                int bucketIdIndex = cur.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID);

                do
                {
                    String _id = cur.getString(photoIDIndex);
                    String path = cur.getString(photoPathIndex);
                    String bucketName = cur.getString(bucketDisplayNameIndex);
                    String bucketId = cur.getString(bucketIdIndex);

                    ImageaIbum bucket = mBucketList.get(bucketId);
                    if (bucket == null)
                    {
                        bucket = new ImageaIbum();
                        mBucketList.put(bucketId, bucket);
                        bucket.imageList = new ArrayList<ImageItem>();
                        bucket.bucketName = bucketName;
                    }
                    bucket.count++;
                    ImageItem imageItem = new ImageItem();
                    imageItem.imageId = _id;
                    imageItem.sourcePath = path;
                    imageItem.thumbnailPath = mThumbnailList.get(_id);
                    bucket.imageList.add(imageItem);

                }
                while (cur.moveToNext());
            }

            hasBuildImagesBucketList = true;
            long endTime = System.currentTimeMillis();
            Log.d(ImageFetcher.class.getName(), "use time: "
                    + (endTime - startTime) + " ms");
        }
        finally
        {
            cur.close();
        }
    }

    /**
     * 得到缩略图
     */
    private void getThumbnail()
    {
        Cursor cursor = null;
        try
        {
            String[] projection = { MediaStore.Images.Thumbnails.IMAGE_ID, MediaStore.Images.Thumbnails.DATA };
            cursor = mContext.getContentResolver().query(
                    MediaStore.Images.Thumbnails.EXTERNAL_CONTENT_URI, projection, null, null,
                    null);
            getThumbnailColumnData(cursor);
        }
        finally
        {
            cursor.close();
        }
    }

    /**
     * 从数据库中得到缩略图
     *
     * @param cur
     */
    private void getThumbnailColumnData(Cursor cur)
    {
        if (cur.moveToFirst())
        {
            int image_id;
            String image_path;
            int image_idColumn = cur.getColumnIndex(MediaStore.Images.Thumbnails.IMAGE_ID);
            int dataColumn = cur.getColumnIndex(MediaStore.Images.Thumbnails.DATA);

            do
            {
                image_id = cur.getInt(image_idColumn);
                image_path = cur.getString(dataColumn);

                mThumbnailList.put("" + image_id, image_path);
            }
            while (cur.moveToNext());
        }
    }
}
