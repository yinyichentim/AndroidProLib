package com.szmm.quoteslib.weight.imageselector;

import java.util.ArrayList;

/**
 * Created by zgh on 2016/8/23.
 */
public class ImageaIbum {
    public int count = 0;
    public String bucketName;
    public ArrayList<ImageItem> imageList;
    public boolean selected = false;

    public ArrayList<ImageItem> getImageList() {
        return imageList;
    }

    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public void setImageList(ArrayList<ImageItem> imageList) {
        this.imageList = imageList;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
