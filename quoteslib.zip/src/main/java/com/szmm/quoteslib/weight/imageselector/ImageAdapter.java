package com.szmm.quoteslib.weight.imageselector;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.szmm.quoteslib.R;

import java.util.ArrayList;

/**
 * Created by Administrator on 2016/8/24 0024.
 */
public class ImageAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<ImageItem> mDataList;
    public ImageAdapter(Context context, ArrayList<ImageItem> mDataList){
        this.context = context;
        this.mDataList = mDataList;
    }
    public void setmDataList(ArrayList<ImageItem> mDataList){
        this.mDataList = mDataList;
    }
    @Override
    public int getCount() {
        return mDataList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
            final ViewHolder mHolder;

            if (convertView == null) {
                convertView = View.inflate(context, R.layout.imageselector_gridview_item, null);
                mHolder = new ViewHolder();
                mHolder.imageIv = (ImageView) convertView.findViewById(R.id.imageSelector_show_iv);
                mHolder.selectedIv = (ImageView) convertView.findViewById(R.id.imageSelector_isSelected);
                mHolder.backgroundTv = (TextView) convertView.findViewById(R.id.imageSelector_show_tv);
                convertView.setTag(mHolder);
            } else {
                mHolder = (ViewHolder) convertView.getTag();
            }

            final ImageItem item = mDataList.get(position);

            ImageSelectorDisplayer.getInstance(context).displayBmp(mHolder.imageIv,
                    item.thumbnailPath, item.sourcePath);

            if (item.isSelected) {
                mHolder.selectedIv.setImageDrawable(context.getResources()
                        .getDrawable(R.drawable.imageselected));
                mHolder.selectedIv.setVisibility(View.VISIBLE);
                mHolder.backgroundTv.setBackgroundColor(Color.GREEN);
            } else {
                mHolder.selectedIv.setImageDrawable(null);
                mHolder.selectedIv.setVisibility(View.GONE);
                mHolder.backgroundTv.setBackgroundColor(Color.GRAY);
            }

            return convertView;
    }
        static class ViewHolder{
            private ImageView imageIv;
            private ImageView selectedIv;
            private TextView backgroundTv;
        }
}
