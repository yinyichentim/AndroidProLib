package com.szmm.quoteslib.weight.imageselector;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.szmm.quoteslib.R;

import java.util.List;

/**
 * Created by zgh on 2016/8/23.
 */
public class ImageSelectorAdapter extends BaseAdapter {
    private List<ImageaIbum> mDataList;
    private Context mContext;

    public ImageSelectorAdapter(Context context, List<ImageaIbum> dataList)
    {
        this.mContext = context;
        this.mDataList = dataList;
    }

    @Override
    public int getCount()
    {
        return mDataList.size();
    }

    @Override
    public Object getItem(int position)
    {
        return mDataList.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        final ViewHolder mHolder;
        if (convertView == null)
        {
            convertView = View.inflate(mContext, R.layout.imageselector_listview_item,
                    null);
            mHolder = new ViewHolder();
            mHolder.coverIv = (ImageView) convertView.findViewById(R.id.imageSelector_iv);
            mHolder.titleTv = (TextView) convertView.findViewById(R.id.imageSelector_title_tv);
            mHolder.countTv = (TextView) convertView.findViewById(R.id.imageSelector_count_tv);
            convertView.setTag(mHolder);
        }
        else
        {
            mHolder = (ViewHolder) convertView.getTag();
        }

        final ImageaIbum item = mDataList.get(position);

        if (item.imageList != null && item.imageList.size() > 0)
        {
            String thumbPath = item.imageList.get(0).thumbnailPath;
            String sourcePath = item.imageList.get(0).sourcePath;

                ImageSelectorDisplayer.getInstance(mContext).displayBmp(mHolder.coverIv, thumbPath,
                        sourcePath);

        }
        else
        {
            mHolder.coverIv.setImageBitmap(null);
        }

        mHolder.titleTv.setText(item.bucketName);
        mHolder.countTv.setText(item.count + ""+mContext.getResources().getString(R.string.imageselector_page));

        return convertView;
    }

    static class ViewHolder
    {
        private ImageView coverIv;
        private TextView titleTv;
        private TextView countTv;
    }
}
