package com.szmm.quoteslib.weight.headimgzoomPicker;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.text.SimpleDateFormat;

/**
 * Created by tim on 2016/4/1.
 */
//返回需要一个全局的drr，表示路径
public class HeadPhotoUtil {
    //拍照触发函数
    public static Uri photo(Activity activity,int camera_code) {
        try {
            Intent openCameraIntent = new Intent(
                    MediaStore.ACTION_IMAGE_CAPTURE);

            String sdcardState = Environment.getExternalStorageState();
            String sdcardPathDir = Environment
                    .getExternalStorageDirectory().getPath() + "/tempImage/";
            File file = null;
            if (Environment.MEDIA_MOUNTED.equals(sdcardState)) {
                // 有sd卡，是否有myImage文件夹
                File fileDir = new File(sdcardPathDir);
                if (!fileDir.exists()) {
                    fileDir.mkdirs();
                }
                // 是否有headImg文件
                file = new File(sdcardPathDir + System.currentTimeMillis()
                        + ".JPEG");
            }
            if (file != null) {
                //path = file.getPath();
                Uri photoUri = Uri.fromFile(file);
                openCameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);

                activity.startActivityForResult(openCameraIntent, camera_code);
                return photoUri;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }




   /* //拍照、图库选择后的结果处理中调用
    //拍照返回结果进行裁剪操作，然后将裁剪后的图片保存至指定的文件夹
    public static String startPhotoZoom(Activity activity, Uri uri, String drr, int zoom_code) {
        try {
            // 获取系统时间 然后将裁剪后的图片保存至指定的文件夹
            SimpleDateFormat sDateFormat = new SimpleDateFormat(
                    "yyyyMMddhhmmss");
            String address = sDateFormat.format(new java.util.Date());
            if (!FileUtils.isFileExist("")) {
                FileUtils.createSDDir("");

            }
            drr = FileUtils.SDPATH + address + ".JPEG";
            Uri imageUri = Uri.parse("file:///sdcard/MTalk/" + address + ".JPEG");//formats

            final Intent intent = new Intent("com.android.camera.action.CROP");

            // 照片URL地址
            intent.setDataAndType(uri, "image*//*");

            intent.putExtra("crop", "true");
            intent.putExtra("aspectX", DisplayUtil.getDisplayWidthPixels(activity.getApplicationContext()));
            intent.putExtra("aspectY", DisplayUtil.getDisplayWidthPixels(activity.getApplicationContext()));
            intent.putExtra("outputX", 480);
            intent.putExtra("outputY", 480);
            intent.putExtra("scale",true);
            intent.putExtra("scaleUpIfNeeded", true);
            // 输出路径
            intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
            // 输出格式
            intent.putExtra("outputFormat",
                    Bitmap.CompressFormat.JPEG.toString());
            // 不启用人脸识别
            intent.putExtra("noFaceDetection", false);
            intent.putExtra("return-data", false);
            activity.startActivityForResult(intent, zoom_code);
            return drr;
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }*/
    //可以传入裁剪的比例
    //param scaleX,scaleY
    public static String startPhotoZoom(Activity activity, Uri uri, String drr, int zoom_code,int scaleX,int scaleY) {
        try {
            // 获取系统时间 然后将裁剪后的图片保存至指定的文件夹
            SimpleDateFormat sDateFormat = new SimpleDateFormat(
                    "yyyyMMddhhmmss");
            String address = sDateFormat.format(new java.util.Date());
            if (!FileUtils.isFileExist("")) {
                FileUtils.createSDDir("");

            }
            drr = FileUtils.SDPATH + address + ".JPEG";
            Uri imageUri = Uri.parse("file:///sdcard/MTalk/" + address + ".JPEG");//formats

            final Intent intent = new Intent("com.android.camera.action.CROP");
            // 照片URL地址
            intent.setDataAndType(uri, "image/*");

            intent.putExtra("crop", "true");
            intent.putExtra("aspectX", scaleX);
            intent.putExtra("aspectY", scaleY);
            intent.putExtra("outputX", 40*scaleX);
            intent.putExtra("outputY", 40*scaleY);
            intent.putExtra("scale",true);
            intent.putExtra("scaleUpIfNeeded", true);
            // 输出路径
            intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
            // 输出格式
            intent.putExtra("outputFormat",
                    Bitmap.CompressFormat.JPEG.toString());
            // 不启用人脸识别
            intent.putExtra("noFaceDetection", false);
            intent.putExtra("return-data", false);
            activity.startActivityForResult(intent, zoom_code);
            return drr;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
}
