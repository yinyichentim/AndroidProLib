package com.szmm.quoteslib.weight.imageselector;

import java.io.Serializable;

/**
 * Created by Administrator on 2016/8/24 0024.
 */
public class ImageItem implements Serializable{
    private static final long serialVersionUID = -7188270558443739432L;
    public String imageId;
    public String thumbnailPath;
    public String sourcePath;
    public boolean isSelected = false;

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }

    public String getSourcePath() {
        return sourcePath;
    }
}
