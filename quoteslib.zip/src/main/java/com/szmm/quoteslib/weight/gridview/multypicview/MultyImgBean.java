package com.szmm.quoteslib.weight.gridview.multypicview;

/**
 * @author yzw
 * @version V1.0
 * @company 跨越速运
 * @Description
 * @date 2016/3/22
 */
public class MultyImgBean {

    private String[] mUrl;

    public String[] getUrl() {
        return mUrl;
    }

    public void setUrl(String[] url) {
        this.mUrl = url;
    }
}
