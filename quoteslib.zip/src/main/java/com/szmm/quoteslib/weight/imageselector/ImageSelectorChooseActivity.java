package com.szmm.quoteslib.weight.imageselector;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.szmm.quoteslib.R;

import java.util.ArrayList;

public class ImageSelectorChooseActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView imageView;
    private TextView sure;
    private int chooseCount;
    private ArrayList<ImageItem> mDataList = new ArrayList<ImageItem>();
    private GridView gv;
    private ImageAdapter mAdapter;
    private int checkedCounts = 0;
    private ChooseState state = ChooseState.NOTMORETHAN;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_selector_choose);
        initDate();
        initView();
        imageView.setOnClickListener(this);
        sure.setOnClickListener(this);
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                mDataList.get(position).setSelected(!mDataList.get(position).isSelected);
                TheCap();
                if(state== ChooseState.CHECKEDOVER){
                    mDataList.get(position).setSelected(!mDataList.get(position).isSelected);
                    ImageSelectorToastUtils.showToast(ImageSelectorChooseActivity.this,getResources().getString(R.string.imageselector_more_select)+""+chooseCount+getResources().getString(R.string.imageselector_count));
                    state = ChooseState.NOTMORETHAN;
                    return;
                }
                mAdapter.setmDataList(mDataList);
                mAdapter.notifyDataSetChanged();
                refushTextView();
            }
        });
    }

    private void initDate() {
        chooseCount=getIntent().getIntExtra(ImageSelector.CHOOSE_IMAGE_COUNT,0);
        mDataList = (ArrayList<ImageItem>) getIntent().getSerializableExtra(ImageSelector.CHOOSE_IMAGE_IBUM);
        mAdapter = new ImageAdapter(ImageSelectorChooseActivity.this, mDataList);
    }
    //判断是否达到上限
    private void TheCap(){
        int temp = 0;
        for(int i = 0; i < mDataList.size();i++){
            if(mDataList.get(i).isSelected){
                temp++;
            }
        }
        if(temp >chooseCount){
            state = ChooseState.CHECKEDOVER;
        }
    }
    //刷新右上角的确定按钮上的选择数据
    private void refushTextView(){
        checkedCounts = 0;
        for(int i = 0 ; i < mDataList.size();i++){
            if(mDataList.get(i).isSelected){
                checkedCounts++;
            }
            sure.setText(getResources().getString(R.string.imageselector_sure)+"("+checkedCounts+"/"+chooseCount+")");
        }
    }
    private void initView() {
        imageView = (ImageView) findViewById(R.id.imageSelector_return);
        sure = (TextView) findViewById(R.id.imageSelector_sure);
        sure.setText(getResources().getString(R.string.imageselector_sure)+"(0/"+chooseCount+")");
        gv = (GridView) findViewById(R.id.imageSelector_gv);
        gv.setAdapter(mAdapter);
    }

    @Override
    public void onClick(View v) {
        int i1 = v.getId();
        if (i1 == R.id.imageSelector_return) {
            finish();

        } else if (i1 == R.id.imageSelector_sure) {//将选择的图片路径返回
            Intent intent = new Intent();
            for (int i = 0; i < mDataList.size(); i++) {
                if (mDataList.get(i).isSelected) {
                    ImageSelector.imageList.add(mDataList.get(i).getSourcePath());
                }
            }
            intent.putStringArrayListExtra(ImageSelector.DIRS, ImageSelector.imageList);
            setResult(ImageSelector.SURE, intent);
            finish();
        }
    }
    private enum ChooseState{
        CHECKEDOVER,NOTMORETHAN
    }
}
