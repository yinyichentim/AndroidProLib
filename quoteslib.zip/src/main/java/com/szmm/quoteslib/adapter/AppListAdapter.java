package com.szmm.quoteslib.adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.widget.BaseAdapter;

import java.util.List;

/**
 * Created by Tim on 2016/6/30.
 * 列表适配器基类
 */
public abstract class AppListAdapter<T> extends BaseAdapter {
    protected List<T> mList;
    protected Activity mActivity;
    protected LayoutInflater mInflater;

    public AppListAdapter(List<T> list, Activity mActivity) {
        this.mList = list;
        this.mActivity = mActivity;
        mInflater = LayoutInflater.from(mActivity);
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int position) {
        return mList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
}