package com.szmm.quoteslib.comment;

/**
 * Created by Android-Tim on 2016/9/6.
 * 全局变量
 */
public class GlobalVariable {
    public static final boolean DEBUG = true; //Change it to true in development mode.
    ///////////QKV数据库配置
    public static final String STRUCT_VER_STRING = "1.0.0_A";
    public static final String PUBLIC_LTAG = "QuickKV"; //Default log tag. There is no need to change it.
    public static final String KVDB_FILE_NAME = "database.qkv"; //Default KVDB filename
    public static final String KVDB_NAME = "database"; //Name (must match above)
    public static final String KVDB_EXT = ".qkv"; //Ext (must match above above)
    public static final String EC_PREFIX = "__QKVEC_"; // :-/ Abandoned

    ///////////网络层全局变量

    public static final String DB_CACHE_NAME = "okhttputils_cache.db";
    public static final int DB_CACHE_VERSION = 1;
    public static final String TABLE_NAME = "cache_table";
    public static final int DEFAULT_MILLISECONDS = 10000; //默认的超时时间
    public static final String OKHTTP_TAG = "OKHTTP_TAG";
    public static final String OKHTTP_SERVER_TAG = "OKHTTP_SERVER_TAG";

}
