package com.szmm.quoteslib.comment;

/**
 * Created by Android-Tim on 2016/9/6.
 * 环境变量
 */
public class EnvironmentVariable {
}
